#ifndef SENSOR_AUDIO_H
#define SENSOR_AUDIO_H

#include "adc_config.h"

#define RMS_SIZE         20
#define DECIMATION_AUDIO 1

/**
 * @brief Inicializa el estado interno del procesador de audio.
 *        Llamar una vez antes de usar process_audio_sample().
 */
void audio_init(void);

/**
 * @brief Procesa una muestra cruda del ADC.
 *        Acumula RMS_SIZE muestras y cuando completa la ventana
 *        calcula el RMS y lo imprime en dB.
 *
 * @param sample  Muestra ADC recibida del canal de audio.
 */
void audio_process_sample(adc_sample_t sample);

#endif /* SENSOR_AUDIO_H */
